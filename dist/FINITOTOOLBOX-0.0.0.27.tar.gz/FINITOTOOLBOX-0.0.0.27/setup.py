from setuptools import setup

setup(
    name = 'FINITOTOOLBOX',
    version = '0000.0000.0000.0027',
    author = 'Prof. Wanderlei M. Pereira Junior, Civil Eng. Gabriel B. Carvalho and Civil Eng. José Vitor Carvalho',
    author_email = 'wanderlei_junior@ufcat.edu.br',
    packages = ['FINITO_TOOLBOX']
)